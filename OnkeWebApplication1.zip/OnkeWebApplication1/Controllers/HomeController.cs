﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.IO; // Include for file operations
using OnkeWebApplication1.Models;

namespace OnkeWebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // Modified Index Action to call GetHeroes and pass the data to the view
        public ActionResult Index()
        {
            var heroes = GetHeroes(); // Get the heroes list
            return View(heroes); // Pass the heroes list to the view
        }

        // Additional method to deserialize JSON data and populate the list of HeroesModel
        private List<HeroesModels> GetHeroes()
        {
            // Adjust the path to point to the Content folder
            string path = Server.MapPath("~/Content/data.json");
            string json = System.IO.File.ReadAllText(path);
            var heroes = JsonConvert.DeserializeObject<List<HeroesModels>>(json); // Use Newtonsoft.Json
            return heroes;
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
